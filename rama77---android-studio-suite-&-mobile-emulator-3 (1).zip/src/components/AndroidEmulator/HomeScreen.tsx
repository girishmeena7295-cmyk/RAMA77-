import React, { useState, useEffect } from 'react';
import { Phone, Info, Play, MessageCircle } from 'lucide-react';
import { backendApiStore } from '../../data/backendApiStore';
import { MarketItem } from '../../types';
import { showNativeAlert } from './nativeAlertStore';

interface HomeScreenProps {
  onSelectMarket: (market: MarketItem) => void;
  darkMode: boolean;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onSelectMarket,
  darkMode,
}) => {
  const [activeCategory, setActiveCategory] = useState<'starline' | 'jackpot' | null>(null);
  const [markets, setMarkets] = useState<MarketItem[]>(backendApiStore.getMarkets());
  const [config, setConfig] = useState(backendApiStore.getConfig());

  useEffect(() => {
    const unsub = backendApiStore.subscribe(() => {
      setMarkets(backendApiStore.getMarkets());
      setConfig(backendApiStore.getConfig());
    });
    return unsub;
  }, []);

  return (
    <div
      className={`h-full overflow-y-auto pb-20 ${
        darkMode ? 'bg-zinc-950 text-white' : 'bg-[#F8F9FA] text-slate-900'
      }`}
    >
      {/* Notice Banner: Light orange background tint with italicized limit notice (Screenshot 1) */}
      <div className="bg-[#FFEBD4] text-[#2D2522] italic font-semibold text-[13px] py-2 px-3 text-center border-b border-[#FFD6A8] shadow-2xs tracking-wide">
        Current minimum deposit limit Rs. 300
      </div>

      <div className="p-3.5 space-y-3">
        {/* Quick Contact Row 1: Call Now & Whatsapp (White rounded pill with orange border) */}
        <div className="grid grid-cols-2 gap-3">
          <a
            href={`tel:${config.supportPhone}`}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white rounded-full shadow-2xs border-2 border-[#FF7A00] hover:bg-orange-50 font-black text-xs text-[#FF7A00] transition-all active:scale-98"
          >
            <Phone className="w-4 h-4 fill-[#FF7A00] text-[#FF7A00]" />
            <span>Call Now</span>
          </a>

          <a
            href={`https://api.whatsapp.com/send?phone=${config.supportWhatsapp}&text=Hello%20Rama77%20Support`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white rounded-full shadow-2xs border-2 border-[#FF7A00] hover:bg-orange-50 font-black text-xs text-[#FF7A00] transition-all active:scale-98"
          >
            <MessageCircle className="w-4 h-4 text-[#FF7A00] fill-[#FF7A00]/20" />
            <span>Whatsapp</span>
          </a>
        </div>

        {/* Quick Action Row 2: Bombay Starline & Bombay Jackpot (Solid orange filled rounded buttons) */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setActiveCategory(activeCategory === 'starline' ? null : 'starline')}
            className="py-2.5 px-3 rounded-full text-xs font-black transition-all shadow-xs bg-[#FF7A00] hover:bg-[#E06A00] active:scale-98 text-white"
          >
            Bombay Starline
          </button>

          <button
            onClick={() => setActiveCategory(activeCategory === 'jackpot' ? null : 'jackpot')}
            className="py-2.5 px-3 rounded-full text-xs font-black transition-all shadow-xs bg-[#FF7A00] hover:bg-[#E06A00] active:scale-98 text-white"
          >
            Bombay Jackpot
          </button>
        </div>

        {/* Active Category Notification */}
        {activeCategory && (
          <div className="bg-orange-50 text-orange-950 text-xs px-3 py-2 rounded-xl flex items-center justify-between border border-orange-200">
            <span>Viewing {activeCategory === 'starline' ? 'Bombay Starline' : 'Bombay Jackpot'} results</span>
            <button
              onClick={() => setActiveCategory(null)}
              className="text-orange-950 font-bold hover:underline"
            >
              Clear
            </button>
          </div>
        )}

        {/* Market Cards List matching Screenshot 1 */}
        <div className="space-y-3 pt-1">
          {markets.map((market) => {
            const isClosed = market.status === 'Closed for Today';
            const isRunningClose = market.status === 'Running for Close';

            const handleCardClick = () => {
              if (isClosed) {
                showNativeAlert({
                  title: `${market.name} is Closed`,
                  message: `Bidding for ${market.name} has concluded for today.\n\nDeclared Result: ${market.openPana}-${market.jodi}-${market.closePana}\n\nMarket will re-open tomorrow at ${market.openTime}.`,
                  type: 'info',
                });
                return;
              }
              onSelectMarket(market);
            };

            return (
              <div
                key={market.id}
                onClick={handleCardClick}
                className={`rounded-2xl p-4 transition-all cursor-pointer hover:shadow-md ${
                  darkMode
                    ? 'bg-zinc-900 border border-zinc-800 hover:border-orange-500/40'
                    : 'bg-white border border-slate-200 shadow-2xs hover:border-[#FF7A00]/60'
                }`}
              >
                {/* Top Row: Market Title & Info icon + Grey Play Button */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-black text-sm tracking-wide text-[#FF7A00] uppercase">
                      {market.name}
                    </h4>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        showNativeAlert({
                          title: market.name,
                          message: `Open Time: ${market.openTime}\nClose Time: ${market.closeTime}\nCurrent Status: ${market.status}`,
                          type: 'info',
                        });
                      }}
                      className="text-[#FF7A00] hover:text-orange-600 p-0.5 cursor-pointer"
                      title="Market Details"
                    >
                      <Info className="w-3.5 h-3.5 stroke-[2.5]" />
                    </button>
                  </div>

                  {/* Play Button: Bright Gradient Orange for Running for Open / Active markets, Grey for Closed */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCardClick();
                    }}
                    className={`flex items-center gap-1.5 px-5 py-1.5 rounded-full text-xs font-black shadow-2xs transition-all active:scale-95 cursor-pointer text-white ${
                      !isClosed
                        ? 'bg-gradient-to-r from-[#FF7A00] to-[#FF9029] hover:from-[#E06A00] hover:to-[#FF7A00] shadow-md shadow-orange-500/30 ring-1 ring-orange-400/50'
                        : 'bg-[#9E9E9E] hover:bg-[#8E8E8E]'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5 fill-white text-white" />
                    <span>Play</span>
                  </button>
                </div>

                {/* Middle Row: Large Bold Result Number (e.g. 480-29-234) */}
                <p className="font-black text-lg text-slate-900 tracking-wider mt-1">
                  {market.openPana}-{market.jodi}-{market.closePana}
                </p>

                {/* Bottom Row: Timings on Left, Status on Right */}
                <div className="flex items-end justify-between mt-2 pt-1 border-t border-slate-100">
                  <div className="text-[11.5px] text-slate-600 space-y-0.5 font-semibold">
                    <p>Open Bids : {market.openTime}</p>
                    <p>Close Bids : {market.closeTime}</p>
                  </div>

                  <div className="flex flex-col items-end">
                    <span
                      className={`text-[12px] font-black ${
                        isClosed
                          ? 'text-[#DC2626]'
                          : isRunningClose
                          ? 'text-amber-600'
                          : 'text-[#16A34A]'
                      }`}
                    >
                      {market.status}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
