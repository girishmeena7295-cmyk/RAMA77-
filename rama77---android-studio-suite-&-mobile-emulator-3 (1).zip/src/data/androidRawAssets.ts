import { AndroidFile } from '../types';

export const ANDROID_RAW_ASSETS: AndroidFile[] = [
  // 1. lottie_splash.json (App Opening Brand Reveal Animation)
  {
    path: 'app/src/main/res/raw/lottie_splash.json',
    category: 'raw',
    language: 'json',
    description: 'High-res Lottie JSON animation for RAMA77 Splash & Brand reveal (Gold badge, pulse rings, orange radiance)',
    content: JSON.stringify(
      {
        v: '5.9.0',
        fr: 60,
        ip: 0,
        op: 120,
        w: 500,
        h: 500,
        nm: 'rama77_splash_reveal',
        ddd: 0,
        assets: [],
        layers: [
          {
            ddd: 0,
            ind: 1,
            ty: 4,
            nm: 'Gold_Shield_Outer',
            sr: 1,
            ks: {
              o: { k: [{ t: 0, s: [0] }, { t: 30, s: [100] }] },
              r: { k: [{ t: 0, s: [-45] }, { t: 45, s: [0] }] },
              p: { k: [250, 250, 0] },
              a: { k: [0, 0, 0] },
              s: {
                k: [
                  { t: 0, s: [0, 0, 100] },
                  { t: 40, s: [115, 115, 100] },
                  { t: 55, s: [100, 100, 100] },
                ],
              },
            },
            ao: 0,
            shapes: [
              {
                ty: 'gr',
                it: [
                  {
                    ty: 'rc',
                    d: 1,
                    s: { k: [180, 180] },
                    p: { k: [0, 0] },
                    r: { k: 40 },
                    nm: 'Shield_Rect',
                  },
                  {
                    ty: 'st',
                    c: { k: [0.945, 0.396, 0.129, 1] }, // #F16521
                    o: { k: 100 },
                    w: { k: 8 },
                    lc: 2,
                    lj: 2,
                    nm: 'Border_Orange',
                  },
                  {
                    ty: 'fl',
                    c: { k: [0.118, 0.118, 0.145, 1] }, // Dark BG
                    o: { k: 95 },
                    r: 1,
                    nm: 'Fill_Dark',
                  },
                  {
                    ty: 'tr',
                    p: { k: [0, 0] },
                    a: { k: [0, 0] },
                    s: { k: [100, 100] },
                    r: { k: 0 },
                    o: { k: 100 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Shield_Group',
              },
            ],
            ip: 0,
            op: 120,
            st: 0,
            bm: 0,
          },
          {
            ddd: 0,
            ind: 2,
            ty: 4,
            nm: 'R77_Crown_Star',
            sr: 1,
            ks: {
              o: { k: [{ t: 20, s: [0] }, { t: 50, s: [100] }] },
              r: { k: [{ t: 30, s: [0] }, { t: 90, s: [360] }] },
              p: { k: [250, 250, 0] },
              a: { k: [0, 0, 0] },
              s: { k: [{ t: 25, s: [30, 30, 100] }, { t: 60, s: [100, 100, 100] }] },
            },
            ao: 0,
            shapes: [
              {
                ty: 'gr',
                it: [
                  {
                    ty: 'sr',
                    sy: 1,
                    d: 1,
                    pt: { k: 6 },
                    p: { k: [0, 0] },
                    r: { k: 0 },
                    or: { k: 48 },
                    os: { k: 0 },
                    ir: { k: 22 },
                    is: { k: 0 },
                    nm: 'Star',
                  },
                  {
                    ty: 'fl',
                    c: { k: [1, 0.753, 0.118, 1] }, // Gold #FFC01E
                    o: { k: 100 },
                    r: 1,
                    nm: 'Fill_Gold',
                  },
                  {
                    ty: 'tr',
                    p: { k: [0, 0] },
                    a: { k: [0, 0] },
                    s: { k: [100, 100] },
                    r: { k: 0 },
                    o: { k: 100 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Crown_Star',
              },
            ],
            ip: 0,
            op: 120,
            st: 0,
            bm: 0,
          },
        ],
      },
      null,
      2
    ),
  },

  // 2. lottie_wallet.json (Coin Spin & Sparkle for Funds & Deposits)
  {
    path: 'app/src/main/res/raw/lottie_wallet.json',
    category: 'raw',
    language: 'json',
    description: 'High-res Lottie JSON animation for Wallet balance, coin spin, and instant deposit celebrations',
    content: JSON.stringify(
      {
        v: '5.9.0',
        fr: 60,
        ip: 0,
        op: 90,
        w: 400,
        h: 400,
        nm: 'wallet_coin_spin',
        ddd: 0,
        assets: [],
        layers: [
          {
            ddd: 0,
            ind: 1,
            ty: 4,
            nm: 'Spinning_Rupee_Coin',
            sr: 1,
            ks: {
              o: { k: 100 },
              r: { k: 0 },
              p: { k: [200, 200, 0] },
              a: { k: [0, 0, 0] },
              s: {
                k: [
                  { t: 0, s: [100, 100, 100] },
                  { t: 22, s: [10, 100, 100] },
                  { t: 45, s: [-100, 100, 100] },
                  { t: 68, s: [-10, 100, 100] },
                  { t: 90, s: [100, 100, 100] },
                ],
              },
            },
            ao: 0,
            shapes: [
              {
                ty: 'gr',
                it: [
                  {
                    ty: 'el',
                    d: 1,
                    s: { k: [150, 150] },
                    p: { k: [0, 0] },
                    nm: 'Coin_Circle',
                  },
                  {
                    ty: 'st',
                    c: { k: [0.89, 0.65, 0.1, 1] },
                    o: { k: 100 },
                    w: { k: 8 },
                    lc: 2,
                    lj: 2,
                    nm: 'Coin_Border',
                  },
                  {
                    ty: 'fl',
                    c: { k: [1, 0.82, 0.18, 1] }, // Shiny Gold
                    o: { k: 100 },
                    r: 1,
                    nm: 'Coin_Gold_Fill',
                  },
                  {
                    ty: 'tr',
                    p: { k: [0, 0] },
                    a: { k: [0, 0] },
                    s: { k: [100, 100] },
                    r: { k: 0 },
                    o: { k: 100 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Coin_Shape',
              },
            ],
            ip: 0,
            op: 90,
            st: 0,
            bm: 0,
          },
        ],
      },
      null,
      2
    ),
  },

  // 3. lottie_success.json (Checkmark & Confetti for Winning / Bid Placement)
  {
    path: 'app/src/main/res/raw/lottie_success.json',
    category: 'raw',
    language: 'json',
    description: 'High-res Lottie JSON animation for successful bid placement & wallet transactions with green badge',
    content: JSON.stringify(
      {
        v: '5.9.0',
        fr: 60,
        ip: 0,
        op: 90,
        w: 400,
        h: 400,
        nm: 'bid_success_animation',
        ddd: 0,
        assets: [],
        layers: [
          {
            ddd: 0,
            ind: 1,
            ty: 4,
            nm: 'Green_Success_Badge',
            sr: 1,
            ks: {
              o: { k: 100 },
              r: { k: 0 },
              p: { k: [200, 200, 0] },
              a: { k: [0, 0, 0] },
              s: {
                k: [
                  { t: 0, s: [0, 0, 100] },
                  { t: 25, s: [120, 120, 100] },
                  { t: 40, s: [100, 100, 100] },
                ],
              },
            },
            ao: 0,
            shapes: [
              {
                ty: 'gr',
                it: [
                  {
                    ty: 'el',
                    d: 1,
                    s: { k: [160, 160] },
                    p: { k: [0, 0] },
                    nm: 'Circle_Badge',
                  },
                  {
                    ty: 'fl',
                    c: { k: [0.086, 0.639, 0.29, 1] }, // Emerald Green #16A34A
                    o: { k: 100 },
                    r: 1,
                    nm: 'Fill_Green',
                  },
                  {
                    ty: 'tr',
                    p: { k: [0, 0] },
                    a: { k: [0, 0] },
                    s: { k: [100, 100] },
                    r: { k: 0 },
                    o: { k: 100 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Badge_Group',
              },
            ],
            ip: 0,
            op: 90,
            st: 0,
            bm: 0,
          },
        ],
      },
      null,
      2
    ),
  },

  // 4. lottie_security.json (Biometric & Anti-Tamper Shield Pulse)
  {
    path: 'app/src/main/res/raw/lottie_security.json',
    category: 'raw',
    language: 'json',
    description: 'High-res Lottie JSON animation for device integrity, biometric scanning, and encrypted MPIN unlock',
    content: JSON.stringify(
      {
        v: '5.9.0',
        fr: 60,
        ip: 0,
        op: 100,
        w: 400,
        h: 400,
        nm: 'security_shield_scan',
        ddd: 0,
        assets: [],
        layers: [
          {
            ddd: 0,
            ind: 1,
            ty: 4,
            nm: 'Security_Radar_Pulse',
            sr: 1,
            ks: {
              o: {
                k: [
                  { t: 0, s: [100] },
                  { t: 60, s: [0] },
                  { t: 61, s: [100] },
                  { t: 100, s: [20] },
                ],
              },
              r: { k: 0 },
              p: { k: [200, 200, 0] },
              a: { k: [0, 0, 0] },
              s: {
                k: [
                  { t: 0, s: [60, 60, 100] },
                  { t: 60, s: [140, 140, 100] },
                  { t: 61, s: [60, 60, 100] },
                  { t: 100, s: [130, 130, 100] },
                ],
              },
            },
            ao: 0,
            shapes: [
              {
                ty: 'gr',
                it: [
                  {
                    ty: 'el',
                    d: 1,
                    s: { k: [140, 140] },
                    p: { k: [0, 0] },
                    nm: 'Radar_Circle',
                  },
                  {
                    ty: 'st',
                    c: { k: [0.945, 0.396, 0.129, 0.8] },
                    o: { k: 100 },
                    w: { k: 4 },
                    lc: 2,
                    lj: 2,
                    nm: 'Radar_Stroke',
                  },
                  {
                    ty: 'tr',
                    p: { k: [0, 0] },
                    a: { k: [0, 0] },
                    s: { k: [100, 100] },
                    r: { k: 0 },
                    o: { k: 100 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Radar_Group',
              },
            ],
            ip: 0,
            op: 100,
            st: 0,
            bm: 0,
          },
        ],
      },
      null,
      2
    ),
  },

  // 5. app/proguard-rules.pro (Engineered to balance optimization while maintaining 15-20MB release APK)
  {
    path: 'app/proguard-rules.pro',
    category: 'config',
    language: 'pro',
    description: 'ProGuard/R8 rules preserving Lottie, Glide, Retrofit, Gson models, Coroutines, and native libraries for ~15-20MB APK',
    content: `# ProGuard / R8 Optimization Rules for Rama77 (com.rama77.app)
# Designed for robust release builds preserving high-fidelity UI assets, Lottie, Glide, and Retrofit 2

# === General AndroidX & Core ===
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**

# === RAMA77 Data Models & Serialization ===
# Preserve all data classes from being obfuscated or stripped by R8
-keep class com.rama77.app.data.models.** { *; }
-keepclassmembers class com.rama77.app.data.models.** {
    <fields>;
    <methods>;
}

# === Retrofit 2 & OkHttp 4 ===
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations

# === Google Gson Serialization ===
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    !static !transient <fields>;
    !private <fields>;
    !static !transient <methods>;
    !private <methods>;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
    @com.google.gson.annotations.Expose <fields>;
}

# === Airbnb Lottie Animation Library ===
# Preserve Lottie classes, composition loaders, and parser reflections
-keep class com.airbnb.lottie.** { *; }
-keep interface com.airbnb.lottie.** { *; }
-dontwarn com.airbnb.lottie.**

# === Bumptech Glide Image Loader ===
# Preserve GlideModule, ModelLoaders, and Hardware Bitmap decoders
-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep class com.bumptech.glide.GeneratedAppGlideModuleImpl { *; }
-keepclassmembers class * extends com.bumptech.glide.module.AppGlideModule {
    <init>(...);
}
-keep public enum com.bumptech.glide.load.resource.bitmap.DownsampleStrategy$* {
    **[] $VALUES;
    public *;
}
-dontwarn com.bumptech.glide.**

# === Kotlin Coroutines & Flow ===
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory { *; }
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler { *; }
-keepclassmembernames class kotlinx.coroutines.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**

# === AndroidX Biometric & Security ===
-keep class androidx.biometric.** { *; }
-dontwarn androidx.biometric.**

# === Material Components & ViewBinding ===
-keepclassmembers class * implements androidx.viewbinding.ViewBinding {
    public static ** inflate(...);
    public static ** bind(...);
    public ** getRoot();
}

# Preserve Native C++ Libraries (Uncompressed 4-byte aligned for APK stability)
-keepclasseswithmembernames class * {
    native <methods>;
}
`,
  },

  // 6. LottieHelper.kt (Utility to seamlessly play Lottie animations with vector fallbacks)
  {
    path: 'app/src/main/java/com/rama77/app/utils/LottieHelper.kt',
    category: 'kotlin',
    language: 'kotlin',
    description: 'Kotlin utility to handle Lottie animation playback, loop control, and fallback vector drawables',
    content: `package com.rama77.app.utils

import android.content.Context
import android.view.View
import androidx.annotation.RawRes
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.rama77.app.R

/**
 * LottieHelper: High-performance Lottie animation controller for RAMA77.
 * Provides caching, repeat controls, and fallback handling for smooth 60fps UI.
 */
object LottieHelper {

    /**
     * Set up a LottieAnimationView with custom raw JSON resource
     */
    fun setupAnimation(
        view: LottieAnimationView,
        @RawRes rawResId: Int,
        autoPlay: Boolean = true,
        loop: Boolean = true
    ) {
        view.visibility = View.VISIBLE
        view.setAnimation(rawResId)
        view.repeatCount = if (loop) LottieDrawable.INFINITE else 0
        if (autoPlay) {
            view.playAnimation()
        }
    }

    /**
     * Splash screen brand reveal animation (res/raw/lottie_splash.json)
     */
    fun playSplashIntro(view: LottieAnimationView, onComplete: (() -> Unit)? = null) {
        view.setAnimation(R.raw.lottie_splash)
        view.repeatCount = 0
        view.addAnimatorListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationStart(p0: android.animation.Animator) {}
            override fun onAnimationEnd(p0: android.animation.Animator) {
                onComplete?.invoke()
            }
            override fun onAnimationCancel(p0: android.animation.Animator) {}
            override fun onAnimationRepeat(p0: android.animation.Animator) {}
        })
        view.playAnimation()
    }

    /**
     * Wallet coin spinning animation for deposit screens
     */
    fun startWalletSpin(view: LottieAnimationView) {
        setupAnimation(view, R.raw.lottie_wallet, autoPlay = true, loop = true)
    }

    /**
     * Celebrate bid placement success
     */
    fun showSuccessCelebration(view: LottieAnimationView, onEnd: (() -> Unit)? = null) {
        view.setAnimation(R.raw.lottie_success)
        view.repeatCount = 0
        view.playAnimation()
    }
}
`,
  },

  // 7. ImageLoaderHelper.kt (Glide Image Loader for high-res banners and avatars)
  {
    path: 'app/src/main/java/com/rama77/app/utils/ImageLoaderHelper.kt',
    category: 'kotlin',
    language: 'kotlin',
    description: 'Kotlin helper using Glide for banner image loading, circle avatars, and hardware disk caching',
    content: `package com.rama77.app.utils

import android.content.Context
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.rama77.app.R

/**
 * ImageLoaderHelper: Glide-based image loading engine for RAMA77.
 * Handles high-resolution market banners, game bazaar graphics, and user profiles.
 */
object ImageLoaderHelper {

    /**
     * Load image URL or drawable into ImageView with fade animation and cache strategy
     */
    fun loadImage(
        context: Context,
        imageUrl: String?,
        targetView: ImageView,
        placeholderResId: Int = R.drawable.ic_glide_placeholder,
        errorResId: Int = R.drawable.ic_glide_error
    ) {
        Glide.with(context)
            .load(imageUrl)
            .apply(
                RequestOptions()
                    .placeholder(placeholderResId)
                    .error(errorResId)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
            )
            .into(targetView)
    }

    /**
     * Load circular user avatar for Drawer header & settings
     */
    fun loadCircularAvatar(
        context: Context,
        avatarUrl: String?,
        targetView: ImageView
    ) {
        Glide.with(context)
            .load(avatarUrl)
            .apply(
                RequestOptions()
                    .circleCrop()
                    .placeholder(R.drawable.bg_avatar_circle)
                    .error(R.drawable.bg_avatar_circle)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
            )
            .into(targetView)
    }

    /**
     * Preload critical game banners to avoid UI jank during navigation
     */
    fun preloadBanner(context: Context, bannerUrl: String) {
        Glide.with(context)
            .load(bannerUrl)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .preload()
    }
}
`,
  },
];
