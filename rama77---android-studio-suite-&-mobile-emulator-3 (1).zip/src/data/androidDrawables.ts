import { AndroidFile } from '../types';

export const ANDROID_DRAWABLES: AndroidFile[] = [
  // 0a. bg_mpin_box.xml (Square outlined rounded box for MPIN 4-digit input)
  {
    path: 'app/src/main/res/drawable/bg_mpin_box.xml',
    category: 'drawable',
    language: 'xml',
    description: 'White background rounded box with border for MPIN edittext',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <stroke android:width="1.5dp" android:color="#CBD5E1" />
    <corners android:radius="12dp" />
</shape>`,
  },

  // 1. bg_button_orange.xml
  {
    path: 'app/src/main/res/drawable/bg_button_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Rounded primary orange button background with ripple',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="#F16521" />
            <corners android:radius="12dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 2. bg_orange_gradient_button.xml
  {
    path: 'app/src/main/res/drawable/bg_orange_gradient_button.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Gradient action button for confirm and play buttons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="0"
        android:startColor="#F16521"
        android:endColor="#D84B06"
        android:type="linear" />
    <corners android:radius="12dp" />
</shape>`,
  },

  // 3. bg_orange_gradient_drawer.xml
  {
    path: 'app/src/main/res/drawable/bg_orange_gradient_drawer.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Header gradient for navigation drawer',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="135"
        android:startColor="#F16521"
        android:endColor="#C2410C"
        android:type="linear" />
</shape>`,
  },

  // 4. bg_white_rounded_card.xml
  {
    path: 'app/src/main/res/drawable/bg_white_rounded_card.xml',
    category: 'drawable',
    language: 'xml',
    description: 'White or elevated card background with rounded corners and border',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <corners android:radius="14dp" />
    <stroke android:width="1dp" android:color="#E5E7EB" />
</shape>`,
  },

  // 5. bg_card_dark.xml
  {
    path: 'app/src/main/res/drawable/bg_card_dark.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Dark surface card background for dark mode components',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#1E1E24" />
    <corners android:radius="16dp" />
    <stroke android:width="1dp" android:color="#2D2D35" />
</shape>`,
  },

  // 6. bg_wallet_pill.xml
  {
    path: 'app/src/main/res/drawable/bg_wallet_pill.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Pill shaped badge container for user balance in toolbar',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#26FFFFFF" />
    <corners android:radius="20dp" />
    <stroke android:width="1dp" android:color="#40FFFFFF" />
</shape>`,
  },

  // 7. bg_orange_circle.xml & bg_avatar_circle.xml
  {
    path: 'app/src/main/res/drawable/bg_orange_circle.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Circle background for icons and avatars',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#F16521" />
</shape>`,
  },
  {
    path: 'app/src/main/res/drawable/bg_avatar_circle.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Circular container for profile picture',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#FFFFFF" />
    <stroke android:width="2dp" android:color="#F16521" />
</shape>`,
  },

  // 8. bg_badge_amount_green.xml
  {
    path: 'app/src/main/res/drawable/bg_badge_amount_green.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Green pill badge for credit / success transactions',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#10B981" />
    <corners android:radius="6dp" />
</shape>`,
  },

  // 9. bg_badge_welcome.xml
  {
    path: 'app/src/main/res/drawable/bg_badge_welcome.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Welcome bonus badge with gradient',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="45"
        android:startColor="#F59E0B"
        android:endColor="#F16521"
        android:type="linear" />
    <corners android:radius="8dp" />
</shape>`,
  },

  // 10. bg_bottom_sheet_rounded.xml
  {
    path: 'app/src/main/res/drawable/bg_bottom_sheet_rounded.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Top-rounded sheet background for dialogs and welcome bonus',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <corners
        android:topLeftRadius="24dp"
        android:topRightRadius="24dp"
        android:bottomLeftRadius="0dp"
        android:bottomRightRadius="0dp" />
</shape>`,
  },

  // 11. bg_category_tab_selected.xml
  {
    path: 'app/src/main/res/drawable/bg_category_tab_selected.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Active tab pill for game categories',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#F16521" />
    <corners android:radius="10dp" />
</shape>`,
  },

  // 12. bg_session_container.xml & tabs
  {
    path: 'app/src/main/res/drawable/bg_session_container.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Container outline for Open and Close session tabs',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#F3F4F6" />
    <corners android:radius="12dp" />
</shape>`,
  },
  {
    path: 'app/src/main/res/drawable/bg_session_tab_active.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Active session tab background',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#F16521" />
    <corners android:radius="10dp" />
</shape>`,
  },
  {
    path: 'app/src/main/res/drawable/bg_session_tab_inactive.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Inactive session tab background',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#00000000" />
    <corners android:radius="10dp" />
</shape>`,
  },

  // 13. bg_terms_dialog.xml
  {
    path: 'app/src/main/res/drawable/bg_terms_dialog.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Modal dialog background for withdrawal terms',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <corners android:radius="20dp" />
</shape>`,
  },

  // 14. bg_translucent_circle.xml & pill
  {
    path: 'app/src/main/res/drawable/bg_translucent_circle.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Translucent circle for overlay buttons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#33FFFFFF" />
</shape>`,
  },
  {
    path: 'app/src/main/res/drawable/bg_translucent_pill.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Translucent pill badge for time remaining and status tags',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#20000000" />
    <corners android:radius="16dp" />
</shape>`,
  },

  // 15. bg_page_active_orange.xml & inactive
  {
    path: 'app/src/main/res/drawable/bg_page_active_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Active carousel indicator dot',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#F16521" />
</shape>`,
  },
  {
    path: 'app/src/main/res/drawable/bg_page_inactive.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Inactive carousel indicator dot',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#CBD5E1" />
</shape>`,
  },

  // 16. bg_play_button.xml (Bright Orange Gradient rounded button for active/running markets)
  {
    path: 'app/src/main/res/drawable/bg_play_button.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Bright gradient orange rounded button for active running markets',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <gradient
                android:angle="0"
                android:startColor="#FF7A00"
                android:endColor="#FF9029"
                android:type="linear" />
            <corners android:radius="24dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 16b. bg_play_button_orange.xml
  {
    path: 'app/src/main/res/drawable/bg_play_button_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Bright gradient orange rounded button for active Running for Open markets',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <gradient
                android:angle="0"
                android:startColor="#FF7A00"
                android:endColor="#FF9029"
                android:type="linear" />
            <corners android:radius="24dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 17. bg_logo_icon.xml
  {
    path: 'app/src/main/res/drawable/bg_logo_icon.xml',
    category: 'drawable',
    language: 'xml',
    description: 'RAMA77 logo background container',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="45"
        android:startColor="#F16521"
        android:endColor="#EA580C"
        android:type="linear" />
    <corners android:radius="16dp" />
</shape>`,
  },

  // ------------------ VECTOR DRAWABLES (ICONS) ------------------

  // ic_home.xml
  {
    path: 'app/src/main/res/drawable/ic_home.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for Home bottom navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M10,20v-6h4v6h5v-8h3L12,3 2,12h3v8z" />
</vector>`,
  },

  // ic_wallet.xml & ic_wallet_funds.xml
  {
    path: 'app/src/main/res/drawable/ic_wallet.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for Wallet balance and Funds',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M21,18v1c0,1.1 -0.9,2 -2,2H5c-1.11,0 -2,-0.9 -2,-2V5c0,-1.1 0.89,-2 2,-2h14c1.1,0 2,0.9 2,2v1h-9c-1.11,0 -2,0.9 -2,2v8c0,1.1 0.89,2 2,2h9zm-9,-2h10V8H12v8zm4,-2.5c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z" />
</vector>`,
  },
  {
    path: 'app/src/main/res/drawable/ic_wallet_funds.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for Funds bottom navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M21,18v1c0,1.1 -0.9,2 -2,2H5c-1.11,0 -2,-0.9 -2,-2V5c0,-1.1 0.89,-2 2,-2h14c1.1,0 2,0.9 2,2v1h-9c-1.11,0 -2,0.9 -2,2v8c0,1.1 0.89,2 2,2h9zm-9,-2h10V8H12v8zm4,-2.5c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z" />
</vector>`,
  },

  // ic_clock_history.xml
  {
    path: 'app/src/main/res/drawable/ic_clock_history.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for History bottom navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M11.99,2C6.47,2 2,6.48 2,12s4.47,10 9.99,10C17.52,22 22,17.52 22,12S17.52,2 11.99,2zM12,20c-4.42,0 -8,-3.58 -8,-8s3.58,-8 8,-8 8,3.58 8,8 -3.58,8 -8,8zm0.5,-13H11v6l5.25,3.15 0.75,-1.23 -4.5,-2.67z" />
</vector>`,
  },

  // ic_book_passbook.xml
  {
    path: 'app/src/main/res/drawable/ic_book_passbook.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for Passbook bottom navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M18,2H6c-1.1,0 -2,0.9 -2,2v16c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V4c0,-1.1 -0.9,-2 -2,-2zM6,4h5v8l-2.5,-1.5L6,12V4zm12,16H6v-2h12v2zm0,-4H6V6h12v10z" />
</vector>`,
  },

  // ic_support_headset.xml & ic_headset_support.xml
  {
    path: 'app/src/main/res/drawable/ic_support_headset.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for Support bottom navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12,1c-4.97,0 -9,4.03 -9,9v7c0,1.66 1.34,3 3,3h3v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h3c1.66,0 3,-1.34 3,-3v-7c0,-4.97 -4.03,-9 -9,-9z" />
</vector>`,
  },
  {
    path: 'app/src/main/res/drawable/ic_headset_support.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for Support navigation alias',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12,1c-4.97,0 -9,4.03 -9,9v7c0,1.66 1.34,3 3,3h3v-8H5v-2c0,-3.87 3.13,-7 7,-7s7,3.13 7,7v2h-4v8h3c1.66,0 3,-1.34 3,-3v-7c0,-4.97 -4.03,-9 -9,-9z" />
</vector>`,
  },

  // ic_bell.xml
  {
    path: 'app/src/main/res/drawable/ic_bell.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector notification bell icon',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.9,2 2,2zm6,-6v-5c0,-3.07 -1.63,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.64,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z" />
</vector>`,
  },

  // ic_arrow_back.xml
  {
    path: 'app/src/main/res/drawable/ic_arrow_back.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector arrow back for toolbar navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M20,11H7.83l5.59,-5.59L12,4l-8,8 8,8 1.41,-1.41L7.83,13H20v-2z" />
</vector>`,
  },

  // ic_chevron_right.xml
  {
    path: 'app/src/main/res/drawable/ic_chevron_right.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector right arrow chevron for list items',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M10,6L8.59,7.41 13.17,12l-4.58,4.59L10,18l6,-6z" />
</vector>`,
  },

  // ic_arrow_forward.xml
  {
    path: 'app/src/main/res/drawable/ic_arrow_forward.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector forward arrow indicator for menu items',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12,4l-1.41,1.41L16.17,11H4v2h12.17l-5.58,5.59L12,20l8,-8z" />
</vector>`,
  },

  // ic_call_orange.xml
  {
    path: 'app/src/main/res/drawable/ic_call_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector call icon for quick customer support',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M20.01,15.38c-1.23,0 -2.42,-0.2 -3.53,-0.56 -0.35,-0.12 -0.74,-0.03 -1.02,0.24l-2.2,2.2c-2.83,-1.44 -5.15,-3.75 -6.59,-6.59l2.2,-2.21c0.28,-0.26 0.36,-0.65 0.25,-1C8.76,6.35 8.56,5.16 8.56,3.93 8.56,3.42 8.14,3 7.63,3H4.07C3.56,3 3,3.37 3,3.93c0,9.42 7.64,17.07 17.01,17.07 0.57,0 0.99,-0.56 0.99,-1.07v-3.55c0,-0.51 -0.42,-0.93 -0.99,-0.93z" />
</vector>`,
  },

  // ic_whatsapp_green.xml
  {
    path: 'app/src/main/res/drawable/ic_whatsapp_green.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector WhatsApp icon for quick customer support',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#25D366"
        android:pathData="M16.75,13.96c-0.25,-0.13 -1.5,-0.74 -1.73,-0.82 -0.23,-0.09 -0.4,-0.13 -0.56,0.13 -0.17,0.25 -0.65,0.82 -0.8,0.99 -0.15,0.17 -0.3,0.19 -0.55,0.07 -0.25,-0.13 -1.06,-0.39 -2.02,-1.25 -0.75,-0.67 -1.26,-1.5 -1.41,-1.75 -0.15,-0.25 -0.02,-0.39 0.11,-0.51 0.11,-0.11 0.25,-0.3 0.38,-0.45 0.12,-0.15 0.17,-0.25 0.25,-0.42 0.08,-0.17 0.04,-0.32 -0.02,-0.45 -0.06,-0.13 -0.56,-1.35 -0.77,-1.85 -0.2,-0.49 -0.41,-0.42 -0.56,-0.43H8.38c-0.17,0 -0.45,0.06 -0.69,0.32 -0.24,0.26 -0.91,0.89 -0.91,2.17s0.93,2.52 1.06,2.69c0.13,0.17 1.83,2.8 4.44,3.93 0.62,0.27 1.11,0.43 1.49,0.55 0.63,0.2 1.2,0.17 1.65,0.1 0.5,-0.07 1.5,-0.61 1.71,-1.21 0.21,-0.6 0.21,-1.11 0.15,-1.21 -0.06,-0.1 -0.23,-0.16 -0.48,-0.29zM12,2C6.48,2 2,6.48 2,12c0,1.82 0.49,3.53 1.35,5L2,22l5.15,-1.35C8.56,21.52 10.23,22 12,22c5.52,0 10,-4.48 10,-10S17.52,2 12,2z" />
</vector>`,
  },

  // ic_fingerprint_line.xml
  {
    path: 'app/src/main/res/drawable/ic_fingerprint_line.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector fingerprint icon for Biometric authentication',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M17.81,4.47c-0.08,0 -0.16,-0.02 -0.23,-0.06C15.66,3.42 14,3 12.01,3c-1.98,0 -3.86,0.47 -5.57,1.41 -0.24,0.13 -0.54,0.04 -0.68,-0.2 -0.13,-0.24 -0.04,-0.55 0.2,-0.68C7.86,2.49 9.9,2 12.01,2c2.12,0 3.99,0.47 5.92,1.5 0.24,0.13 0.33,0.44 0.2,0.68 -0.09,0.18 -0.28,0.29 -0.48,0.29zM2.5,9.5c-0.17,0 -0.34,-0.09 -0.43,-0.25 -0.14,-0.24 -0.05,-0.55 0.19,-0.69C4.8,7.06 8.27,6 12,6c3.74,0 7.21,1.06 9.74,2.56 0.24,0.14 0.33,0.45 0.19,0.69 -0.14,0.24 -0.45,0.33 -0.69,0.19C18.89,8 15.58,7 12,7 8.42,7 5.11,8 2.74,9.44c-0.08,0.04 -0.16,0.06 -0.24,0.06zM12,11c-1.66,0 -3,1.34 -3,3v5c0,0.55 0.45,1 1,1s1,-0.45 1,-1v-5c0,-0.55 0.45,-1 1,-1s1,0.45 1,1v5c0,1.66 -1.34,3 -3,3s-3,-1.34 -3,-3v-5c0,-2.76 2.24,-5 5,-5s5,2.24 5,5v3c0,0.55 -0.45,1 -1,1s-1,-0.45 -1,-1v-3c0,-1.66 -1.34,-3 -3,-3z" />
</vector>`,
  },

  // ic_line_chart.xml
  {
    path: 'app/src/main/res/drawable/ic_line_chart.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector chart icon for Matka Charts',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M3.5,18.49l6,-6.01 4,4L22,6.92l-1.41,-1.41 -7.09,7.97 -4,-4L2,16.99z" />
</vector>`,
  },

  // ic_lock_key.xml
  {
    path: 'app/src/main/res/drawable/ic_lock_key.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector lock icon for Change MPIN',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zm-6,9c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2zm3.1,-9H8.9V6c0,-1.71 1.39,-3.1 3.1,-3.1 1.71,0 3.1,1.39 3.1,3.1v2z" />
</vector>`,
  },

  // ic_log_out.xml
  {
    path: 'app/src/main/res/drawable/ic_log_out.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector logout icon for navigation drawer',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#EF4444"
        android:pathData="M17,7l-1.41,1.41L18.17,11H8v2h10.17l-2.58,2.58L17,17l5,-5zM4,5h8V3H4c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,2 2,2h8v-2H4V5z" />
</vector>`,
  },

  // ic_settings.xml
  {
    path: 'app/src/main/res/drawable/ic_settings.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector gear settings icon',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M19.14,12.94c0.04,-0.3 0.06,-0.61 0.06,-0.94 0,-0.32 -0.02,-0.64 -0.07,-0.94l2.03,-1.58c0.18,-0.14 0.23,-0.41 0.12,-0.61l-1.92,-3.32c-0.12,-0.22 -0.37,-0.29 -0.59,-0.22l-2.39,0.96c-0.5,-0.38 -1.03,-0.7 -1.62,-0.94L14.4,2.81c-0.04,-0.24 -0.24,-0.41 -0.48,-0.41h-3.84c-0.24,0 -0.43,0.17 -0.47,0.41L9.25,5.35C8.66,5.59 8.12,5.92 7.63,6.29L5.24,5.33c-0.22,-0.08 -0.47,0 -0.59,0.22L2.74,8.87c-0.12,0.21 -0.08,0.47 0.12,0.61l2.03,1.58c-0.05,0.3 -0.09,0.63 -0.09,0.94s0.02,0.64 0.07,0.94l-2.03,1.58c-0.18,0.14 -0.23,0.41 -0.12,0.61l1.92,3.32c0.12,0.22 0.37,0.29 0.59,0.22l2.39,-0.96c0.5,0.38 1.03,0.7 1.62,0.94l0.36,2.54c0.05,0.24 0.24,0.41 0.48,0.41h3.84c0.24,0 0.44,-0.17 0.47,-0.41l0.36,-2.54c0.59,-0.24 1.13,-0.56 1.62,-0.94l2.39,0.96c0.22,0.08 0.47,0 0.59,-0.22l1.92,-3.32c0.12,-0.22 0.07,-0.47 -0.12,-0.61l-2.01,-1.58zM12,15.6c-1.98,0 -3.6,-1.62 -3.6,-3.6s1.62,-3.6 3.6,-3.6 3.6,1.62 3.6,3.6 -1.62,3.6 -3.6,3.6z" />
</vector>`,
  },

  // ic_menu.xml
  {
    path: 'app/src/main/res/drawable/ic_menu.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector hamburger menu icon for drawer toggle',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M3,18h18v-2H3v2zm0,-5h18v-2H3v2zm0,-7v2h18V6H3z" />
</vector>`,
  },

  // ic_user.xml
  {
    path: 'app/src/main/res/drawable/ic_user.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector user icon for profile badge',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zm0,2c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z" />
</vector>`,
  },

  // ic_rupee_coin.xml
  {
    path: 'app/src/main/res/drawable/ic_rupee_coin.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector Rupee symbol icon for betting and points',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M13.66,7C13.1,5.82 11.9,5 10.5,5H6V3h12v2h-3.26c0.48,0.58 0.81,1.26 0.92,2H18v2h-2.1c-0.24,1.96 -1.78,3.52 -3.76,3.87L17,21h-3.24l-4.52,-7.5H6v-2h4.5c1.38,0 2.5,-1.12 2.5,-2.5H6V7h7.66z" />
</vector>`,
  },

  // ic_gift_bonus.xml
  {
    path: 'app/src/main/res/drawable/ic_gift_bonus.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector gift bonus icon for registration and promo offers',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F59E0B"
        android:pathData="M20,6h-2.18c0.11,-0.31 0.18,-0.65 0.18,-1 0,-1.66 -1.34,-3 -3,-3 -1.05,0 -1.96,0.54 -2.5,1.35l-0.5,0.67 -0.5,-0.68C10.96,2.54 10.05,2 9,2 7.34,2 6,3.34 6,5c0,0.35 0.07,0.69 0.18,1H4c-1.11,0 -1.99,0.89 -1.99,2L2,19c0,1.11 0.89,2 2,2h16c1.11,0 2,-0.89 2,-2V8c0,-1.11 -0.89,-2 -2,-2zm-5,-2c0.55,0 1,0.45 1,1s-0.45,1 -1,1h-2.22l0.42,-0.57C13.52,4.98 14.22,4 15,4zm-6,0c0.78,0 1.48,0.98 1.8,1.43L11.22,6H9c-0.55,0 -1,-0.45 -1,-1s0.45,-1 1,-1zm11,15H4v-2h16v2zm0,-5H4V8h7.08L9.9,9.49 11.31,10.9 12,10.21l0.69,0.69 1.41,-1.41L12.92,8H20v6z" />
</vector>`,
  },

  // ic_play_arrow.xml
  {
    path: 'app/src/main/res/drawable/ic_play_arrow.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector play icon for market action buttons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M8,5v14l11,-7z" />
</vector>`,
  },

  // ic_starline_small.xml
  {
    path: 'app/src/main/res/drawable/ic_starline_small.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector star icon for Bombay Starline section',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M12,17.27L18.18,21l-1.64,-7.03L22,9.24l-7.19,-0.61L12,2 9.19,8.63 2,9.24l5.46,4.73L5.82,21z" />
</vector>`,
  },

  // ic_target.xml
  {
    path: 'app/src/main/res/drawable/ic_target.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector bullseye target icon for Jackpot section',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M12,2C6.49,2 2,6.49 2,12s4.49,10 10,10 10,-4.49 10,-10S17.51,2 12,2zm0,18c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8zm0,-14c-3.31,0 -6,2.69 -6,6s2.69,6 6,6 6,-2.69 6,-6 -2.69,-6 -6,-6zm0,10c-2.21,0 -4,-1.79 -4,-4s1.79,-4 4,-4 4,1.79 4,4 -1.79,4 -4,4zm0,-6c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z" />
</vector>`,
  },

  // ic_trash.xml
  {
    path: 'app/src/main/res/drawable/ic_trash.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector trash delete icon for removing bids from summary table',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#EF4444"
        android:pathData="M16,9v10H8V9h8m-1.5,-6h-5l-1,1H5v2h14V4h-3.5l-1,-1zM18,7H6v12c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7z" />
</vector>`,
  },

  // ic_share.xml
  {
    path: 'app/src/main/res/drawable/ic_share.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector share icon for drawer menu item',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M18,16.08c-0.76,0 -1.44,0.3 -1.96,0.77L8.91,12.7c0.05,-0.23 0.09,-0.46 0.09,-0.7s-0.04,-0.47 -0.09,-0.7l7.05,-4.11c0.54,0.5 1.25,0.81 2.04,0.81 1.66,0 3,-1.34 3,-3s-1.34,-3 -3,-3 -3,1.34 -3,3c0,0.24 0.04,0.47 0.09,0.7L8.04,9.81C7.5,9.31 6.79,9 6,9c-1.66,0 -3,1.34 -3,3s1.34,3 3,3c0.79,0 1.5,-0.31 2.04,-0.81l7.12,4.16c-0.05,0.21 -0.08,0.43 -0.08,0.65 0,1.61 1.31,2.92 2.92,2.92s2.92,-1.31 2.92,-2.92c0,-1.61 -1.31,-2.92 -2.92,-2.92z" />
</vector>`,
  },

  // ic_moon.xml
  {
    path: 'app/src/main/res/drawable/ic_moon.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector moon icon for Dark Theme toggle in navigation drawer',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12.3,2a10,10 0,0 0,-1.9 0.18,10 10,0 1,1 -8.22,8.22A10,10 0,0 0,12.3 2z" />
</vector>`,
  },

  // ic_message_square.xml
  {
    path: 'app/src/main/res/drawable/ic_message_square.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector message icon for in-app support chat',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M20,2H4c-1.1,0 -1.99,0.9 -1.99,2L2,22l4,-4h14c1.1,0 2,-0.9 2,-2V4c0,-1.1 -0.9,-2 -2,-2zM6,9h12v2H6V9zm8,5H6v-2h8v2zm4,-6H6V6h12v2z" />
</vector>`,
  },

  // ic_help_circle.xml & ic_info_circle_orange.xml
  {
    path: 'app/src/main/res/drawable/ic_help_circle.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector help icon for rules and withdrawal FAQs',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zm1,16h-2v-2h2v2zm1.07,-7.75l-0.9,0.92C12.45,11.9 12,12.5 12,14h-2v-0.5c0,-1.1 0.45,-2.1 1.17,-2.83l1.24,-1.26c0.37,-0.36 0.59,-0.86 0.59,-1.41 0,-1.1 -0.9,-2 -2,-2s-2,0.9 -2,2H7c0,-2.76 2.24,-5 5,-5s5,2.24 5,5c0,1.04 -0.42,1.99 -1.07,2.75z" />
</vector>`,
  },
  {
    path: 'app/src/main/res/drawable/ic_info_circle_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector orange info icon for minimum deposit warning ticker',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zm1,15h-2v-6h2v6zm0,-8h-2V7h2v2z" />
</vector>`,
  },

  // ic_close_circle.xml
  {
    path: 'app/src/main/res/drawable/ic_close_circle.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector close circle for dismissing modals',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#6B7280"
        android:pathData="M12,2C6.47,2 2,6.47 2,12s4.47,10 10,10 10,-4.47 10,-10S17.53,2 12,2zm5,13.59L15.59,17 12,13.41 8.41,17 7,15.59 10.59,12 7,8.41 8.41,7 12,10.59 15.59,7 17,8.41 13.41,12 17,15.59z" />
</vector>`,
  },

  // ic_file_text.xml
  {
    path: 'app/src/main/res/drawable/ic_file_text.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector document icon for terms and conditions',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M14,2H6c-1.1,0 -1.99,0.9 -1.99,2L4,20c0,1.1 0.89,2 1.99,2H18c1.1,0 2,-0.9 2,-2V8l-6,-6zm2,16H8v-2h8v2zm0,-4H8v-2h8v2zm-3,-5V3.5L18.5,9H13z" />
</vector>`,
  },

  // ic_globe.xml
  {
    path: 'app/src/main/res/drawable/ic_globe.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector globe icon for website links',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M11.99,2C6.47,2 2,6.48 2,12s4.47,10 9.99,10C17.52,22 22,17.52 22,12S17.52,2 11.99,2zm6.93,6h-2.95c-0.32,-1.25 -0.78,-2.45 -1.38,-3.56 1.84,0.63 3.37,1.91 4.33,3.56zM12,4.04c0.83,1.2 1.48,2.53 1.91,3.96h-3.82c0.43,-1.43 1.08,-2.76 1.91,-3.96zM4.26,14C4.1,13.36 4,12.69 4,12s0.1,-1.36 0.26,-2h3.38c-0.08,0.66 -0.14,1.32 -0.14,2 0,0.68 0.06,1.34 0.14,2H4.26zm0.82,2h2.95c0.32,1.25 0.78,2.45 1.38,3.56 -1.84,-0.63 -3.37,-1.9 -4.33,-3.56zm2.95,-8H5.08c0.96,-1.66 2.49,-2.93 4.33,-3.56C8.81,5.55 8.35,6.75 8.03,8zM12,19.96c-0.83,-1.2 -1.48,-2.53 -1.91,-3.96h3.82c-0.43,1.43 -1.08,2.76 -1.91,3.96zM14.34,14H9.66c-0.09,-0.66 -0.16,-1.32 -0.16,-2 0,-0.68 0.07,-1.35 0.16,-2h4.68c0.09,0.65 0.16,1.32 0.16,2 0,0.68 -0.07,1.34 -0.16,2zm0.15,5.56c0.6,-1.11 1.06,-2.31 1.38,-3.56h2.95c-0.96,1.65 -2.49,2.93 -4.33,3.56zM16.36,14c0.08,-0.66 0.14,-1.32 0.14,-2 0,-0.68 -0.06,-1.34 -0.14,-2h3.38c0.16,0.64 0.26,1.31 0.26,2s-0.1,1.36 -0.26,2h-3.38z" />
</vector>`,
  },
];
