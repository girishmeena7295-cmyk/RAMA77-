import { AndroidFile } from '../types';

export const ANDROID_RICH_DRAWABLES: AndroidFile[] = [
  // 1. ic_rama77_brand_logo.xml (High-res detailed vector logo with crown and crest)
  {
    path: 'app/src/main/res/drawable/ic_rama77_brand_logo.xml',
    category: 'drawable',
    language: 'xml',
    description: 'High-resolution vector brand logo for RAMA77 with crown, shield crest, and 3D gradient',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="120dp"
    android:height="120dp"
    android:viewportWidth="120"
    android:viewportHeight="120">
    <!-- Outer Glow Circle -->
    <path
        android:fillColor="#1AF16521"
        android:pathData="M60,60m-58,0a58,58 0,1 1,116 0a58,58 0,1 1,-116 0" />
    <!-- Gradient Background Shield -->
    <path
        android:fillColor="#F16521"
        android:pathData="M60,10 L98,28 L98,68 C98,88 80,104 60,110 C40,104 22,88 22,68 L22,28 Z" />
    <!-- Inner Dark Core -->
    <path
        android:fillColor="#1E1E24"
        android:pathData="M60,18 L90,32 L90,66 C90,82 76,96 60,101 C44,96 30,82 30,66 L30,32 Z" />
    <!-- Crown at Top -->
    <path
        android:fillColor="#FFC01E"
        android:pathData="M44,42 L52,50 L60,38 L68,50 L76,42 L74,58 L46,58 Z" />
    <!-- Stylized "77" and "R" Gold Details -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M46,64 L58,64 L58,68 L52,82 L47,82 L52,70 L46,70 Z" />
    <path
        android:fillColor="#FFC01E"
        android:pathData="M62,64 L74,64 L74,68 L68,82 L63,82 L68,70 L62,70 Z" />
</vector>`,
  },

  // 2. bg_splash_hero_gradient.xml (Fullscreen rich gradient background)
  {
    path: 'app/src/main/res/drawable/bg_splash_hero_gradient.xml',
    category: 'drawable',
    language: 'xml',
    description: 'High-resolution fullscreen gradient background for splash and login screens',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="270"
        android:startColor="#F16521"
        android:centerColor="#D84B06"
        android:endColor="#1E1E24"
        android:type="linear" />
</shape>`,
  },

  // 3. bg_dashboard_banner_gradient.xml (Rich hero banner for dashboard)
  {
    path: 'app/src/main/res/drawable/bg_dashboard_banner_gradient.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Dashboard top hero banner gradient card with rounded corners and warm glow',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="45"
        android:startColor="#F16521"
        android:centerColor="#E05410"
        android:endColor="#B43702"
        android:type="linear" />
    <corners android:radius="18dp" />
    <stroke android:width="1dp" android:color="#33FFFFFF" />
</shape>`,
  },

  // 4. bg_gold_vip_card.xml (VIP Club card background)
  {
    path: 'app/src/main/res/drawable/bg_gold_vip_card.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Luxurious gold metallic gradient background for VIP Club and Passbook cards',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="135"
        android:startColor="#D4AF37"
        android:centerColor="#F5D77F"
        android:endColor="#AA7C11"
        android:type="linear" />
    <corners android:radius="16dp" />
    <stroke android:width="1.5dp" android:color="#FFE29A" />
</shape>`,
  },

  // 5. bg_game_bazaar_card.xml (Market Card elevation background)
  {
    path: 'app/src/main/res/drawable/bg_game_bazaar_card.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Card background for Market Bazaar with subtle inner shadow and border',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <corners android:radius="16dp" />
    <stroke android:width="1dp" android:color="#EAECEF" />
</shape>`,
  },

  // 6. bg_jackpot_banner.xml (Deep violet jackpot card)
  {
    path: 'app/src/main/res/drawable/bg_jackpot_banner.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vibrant Bombay Jackpot banner card with purple/indigo gradient',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="90"
        android:startColor="#4C1D95"
        android:centerColor="#6D28D9"
        android:endColor="#7C3AED"
        android:type="linear" />
    <corners android:radius="16dp" />
</shape>`,
  },

  // 7. bg_starline_banner.xml (Navy blue starline card)
  {
    path: 'app/src/main/res/drawable/bg_starline_banner.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Bombay Starline banner card with dark sapphire gradient',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:angle="90"
        android:startColor="#0F172A"
        android:centerColor="#1E293B"
        android:endColor="#334155"
        android:type="linear" />
    <corners android:radius="16dp" />
</shape>`,
  },

  // 8. bg_market_open_badge.xml (Glowing green pill for active markets)
  {
    path: 'app/src/main/res/drawable/bg_market_open_badge.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vibrant green pill badge for markets open and accepting bids',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#DCFCE7" />
    <corners android:radius="20dp" />
    <stroke android:width="1dp" android:color="#86EFAC" />
</shape>`,
  },

  // 9. bg_market_closed_badge.xml (Red pill for closed markets)
  {
    path: 'app/src/main/res/drawable/bg_market_closed_badge.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Red pill badge indicating market betting closed for today',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FEE2E2" />
    <corners android:radius="20dp" />
    <stroke android:width="1dp" android:color="#FCA5A5" />
</shape>`,
  },

  // 10. ic_trophy_gold.xml (Vector gold trophy for winners)
  {
    path: 'app/src/main/res/drawable/ic_trophy_gold.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon of golden winner trophy',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFC01E"
        android:pathData="M19,5h-2V3H7v2H5C3.9,5 3,5.9 3,7v1c0,2.55 1.92,4.63 4.39,4.94A5.01,5.01 0,0 0,11 15.9V19H7v2h10v-2h-4v-3.1c1.94,-0.41 3.48,-1.93 3.61,-3.96C19.08,11.63 21,9.55 21,8V7C21,5.9 20.1,5 19,5zM5,8V7h2v3.82C5.84,10.4 5,9.3 5,8zM19,8c0,1.3 -0.84,2.4 -2,2.82V7h2V8z" />
</vector>`,
  },

  // 11. ic_shield_verified.xml (Vector verified security badge)
  {
    path: 'app/src/main/res/drawable/ic_shield_verified.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for verified device security and anti-tamper',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#16A34A"
        android:pathData="M12,1L3,5v6c0,5.55 3.84,10.74 9,12c5.16,-1.26 9,-6.45 9,-12V5L12,1zM10,17l-4,-4l1.41,-1.41L10,14.17l6.59,-6.59L18,9L10,17z" />
</vector>`,
  },

  // 12. ic_credit_card_chip.xml (Vector chip for payment methods)
  {
    path: 'app/src/main/res/drawable/ic_credit_card_chip.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector icon for UPI, Google Pay, PhonePe, and Bank cards',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F16521"
        android:pathData="M20,4H4C2.89,4 2.01,4.89 2.01,6L2,18c0,1.11 0.89,2 2,2h16c1.11,0 2,-0.89 2,-2V6C22,4.89 21.11,4 20,4zM20,18H4v-6h16V18zM20,8H4V6h16V8z" />
</vector>`,
  },

  // 13. ic_fire_trend.xml (Vector flame icon for hot markets)
  {
    path: 'app/src/main/res/drawable/ic_fire_trend.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector flame icon for trending markets and live jackpots',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#EA580C"
        android:pathData="M13.5,0.67s.74,2.65.74,4.8c0,2.06-1.35,3.73-3.41,3.73-2.07,0-3.63-1.67-3.63-3.73l.03-.36C5.21,7.51 4,10.61 4,14c0,4.42 3.58,8 8,8s8-3.58 8-8C20,8.61 17.41,3.8 13.5,0.67zM11.71,19c-1.78,0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39,1.29.59,2.65.59,4.04 0,2.65-2.15,4.8-4.8,4.8z" />
</vector>`,
  },

  // 14. ic_lightning_instant.xml (Vector lightning bolt for instant withdrawals)
  {
    path: 'app/src/main/res/drawable/ic_lightning_instant.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector lightning bolt for instant deposit and 5-minute withdrawal badge',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FBBF24"
        android:pathData="M7,2v11h3v9l7,-12h-4l4,-8z" />
</vector>`,
  },

  // 15. ic_glide_placeholder.xml (High-res placeholder for Glide image loading)
  {
    path: 'app/src/main/res/drawable/ic_glide_placeholder.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Subtle placeholder drawable shown by Glide while images are loading from CDN',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <path
        android:fillColor="#E5E7EB"
        android:pathData="M0,0h48v48h-48z" />
    <path
        android:fillColor="#9CA3AF"
        android:pathData="M38,38H10c-2.21,0 -4,-1.79 -4,-4V14c0,-2.21 1.79,-4 4,-4h28c2.21,0 4,1.79 4,4v20C42,36.21 40.21,38 38,38zM14,19c1.66,0 3,-1.34 3,-3s-1.34,-3 -3,-3s-3,1.34 -3,3S12.34,19 14,19zM10,34h28l-8.5,-11.33l-6.5,8.67l-4.5,-6.01L10,34z" />
</vector>`,
  },

  // 16. ic_glide_error.xml (High-res error fallback for Glide image loader)
  {
    path: 'app/src/main/res/drawable/ic_glide_error.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Error drawable shown by Glide if network or CDN image loading fails',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <path
        android:fillColor="#FEE2E2"
        android:pathData="M0,0h48v48h-48z" />
    <path
        android:fillColor="#EF4444"
        android:pathData="M24,4C12.95,4 4,12.95 4,24s8.95,20 20,20 20,-8.95 20,-20S35.05,4 24,4zM26,30h-4v-4h4v4zM26,22h-4v-10h4v10z" />
</vector>`,
  },

  // 17. bg_play_button_grey.xml (Screenshot 1: Grey rounded Play button for closed markets)
  {
    path: 'app/src/main/res/drawable/bg_play_button_grey.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Rounded grey Play button matching closed markets',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="#9E9E9E" />
            <corners android:radius="24dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 17b. bg_play_button_disabled.xml
  {
    path: 'app/src/main/res/drawable/bg_play_button_disabled.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Disabled/closed grey rounded Play button',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#9E9E9E" />
    <corners android:radius="24dp" />
</shape>`,
  },

  // 17c. bg_play_button_orange.xml (Bright Orange Gradient rounded button for active/running markets)
  {
    path: 'app/src/main/res/drawable/bg_play_button_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Bright gradient orange rounded button for active Running for Open markets',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <gradient
                android:angle="0"
                android:startColor="#FF7A00"
                android:endColor="#FF9029"
                android:type="linear" />
            <corners android:radius="24dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 18. bg_action_pill_white_orange.xml (Screenshot 1: Call Now / Whatsapp buttons)
  {
    path: 'app/src/main/res/drawable/bg_action_pill_white_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'White rounded pill with orange border for Call Now and Whatsapp',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#20FF7A00">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="#FFFFFF" />
            <stroke android:width="2dp" android:color="#FF7A00" />
            <corners android:radius="24dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 19. bg_action_pill_orange.xml (Screenshot 1: Bombay Starline / Bombay Jackpot)
  {
    path: 'app/src/main/res/drawable/bg_action_pill_orange.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Solid orange rounded button for Bombay Starline and Bombay Jackpot',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="#FF7A00" />
            <corners android:radius="24dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 20. bg_wallet_pill_light.xml (Screenshot 1 & 2: Top bar wallet balance pill)
  {
    path: 'app/src/main/res/drawable/bg_wallet_pill_light.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Light grey pill badge container for wallet balance in top toolbar',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#F1F5F9" />
    <stroke android:width="1dp" android:color="#E2E8F0" />
    <corners android:radius="20dp" />
</shape>`,
  },

  // 21. bg_orange_back_btn.xml (Screenshot 2: Rounded square orange back button)
  {
    path: 'app/src/main/res/drawable/bg_orange_back_btn.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Solid orange rounded square button for back navigation',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="#40FFFFFF">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="#FF7A00" />
            <corners android:radius="12dp" />
        </shape>
    </item>
</ripple>`,
  },

  // 22. bg_notice_banner.xml (Screenshot 1: Notice banner background)
  {
    path: 'app/src/main/res/drawable/bg_notice_banner.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Light peach banner background for minimum deposit limit notice',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFEBD4" />
    <stroke android:width="1dp" android:color="#FFD6A8" />
</shape>`,
  },

  // 23. bg_orange_badge.xml (Screenshot 2: Game Category Icon Orange Badge)
  {
    path: 'app/src/main/res/drawable/bg_orange_badge.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Brand orange rounded badge for bidding game category icons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FF7A00" />
    <corners android:radius="10dp" />
</shape>`,
  },

  // 24. bg_bidding_option_card.xml (Screenshot 2: White rounded card with border)
  {
    path: 'app/src/main/res/drawable/bg_bidding_option_card.xml',
    category: 'drawable',
    language: 'xml',
    description: 'White rounded card background for bidding category option item',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <stroke android:width="1dp" android:color="#E2E8F0" />
    <corners android:radius="16dp" />
</shape>`,
  },

  // 25. ic_dice_1.xml (Single Digit Category Icon)
  {
    path: 'app/src/main/res/drawable/ic_dice_1.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector drawable for Single Digit dice with one central dot',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,3H5C3.9,3 3,3.9 3,5v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2V5C21,3.9 20.1,3 19,3zM12,14c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2z" />
</vector>`,
  },

  // 26. ic_dice_2.xml (Jodi Digit Category Icon)
  {
    path: 'app/src/main/res/drawable/ic_dice_2.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector drawable for Jodi Digit dice with two diagonal dots',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,3H5C3.9,3 3,3.9 3,5v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2V5C21,3.9 20.1,3 19,3zM8.5,10C7.67,10 7,9.33 7,8.5S7.67,7 8.5,7 10,7.67 10,8.5 9.33,10 8.5,10zM15.5,17c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z" />
</vector>`,
  },

  // 27. ic_dice_all.xml (All In One Overlapping Dice Icon)
  {
    path: 'app/src/main/res/drawable/ic_dice_all.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector drawable for All In One overlapping dice',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M17,2H7C5.9,2 5,2.9 5,4v2h12c1.1,0 2,0.9 2,2v8h2c1.1,0 2,-0.9 2,-2V4C23,2.9 22.1,2 21,2H17zM15,6H3C1.9,6 1,6.9 1,8v12c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V8C17,6.9 16.1,6 15,6zM9,15.5c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z" />
</vector>`,
  },

  // 28. ic_card_single.xml (Single Pana Playing Card Icon)
  {
    path: 'app/src/main/res/drawable/ic_card_single.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector drawable for Single Pana playing card with diamond crest',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M17,2H7C5.9,2 5,2.9 5,4v16c0,1.1 0.9,2 2,2h10c1.1,0 2,-0.9 2,-2V4C19,2.9 18.1,2 17,2zM12,7l2.5,3.5L12,14l-2.5,-3.5L12,7z" />
</vector>`,
  },

  // 29. ic_card_double.xml (Double Pana Playing Cards Icon)
  {
    path: 'app/src/main/res/drawable/ic_card_double.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector drawable for Double Pana paired playing cards',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M3,5v14c0,1.1 0.9,2 2,2h11v-2H5V5H3zm14,-3H9c-1.1,0 -2,0.9 -2,2v12c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V4c0,-1.1 -0.9,-2 -2,-2zm-4,9l-2,-2.5 2,-2.5 2,2.5 -2,2.5z" />
</vector>`,
  },

  // 30. ic_card_triple.xml (Triple Pana Three Playing Cards Icon)
  {
    path: 'app/src/main/res/drawable/ic_card_triple.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector drawable for Triple Pana trio of playing cards',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M2,6v14c0,1.1 0.9,2 2,2h12v-2H4V6H2zm4,-4v14c0,1.1 0.9,2 2,2h12v-2H8V2H6zm12,0H12c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h6c1.1,0 2,-0.9 2,-2V4c0,-1.1 -0.9,-2 -2,-2zm-3,8l-1.5,-2 1.5,-2 1.5,2 -1.5,2z" />
</vector>`,
  },

  // 31. ic_gauge.xml (SP Motor / DP Motor Gauge Icon)
  {
    path: 'app/src/main/res/drawable/ic_gauge.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector speedometer gauge for SP/DP motor betting',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M12,2C6.48,2 2,6.48 2,12c0,4.42 2.87,8.17 6.84,9.5c0.41,-0.38 0.66,-0.91 0.66,-1.5v-1.12C6.54,17.47 4.5,14.97 4.5,12c0,-4.14 3.36,-7.5 7.5,-7.5s7.5,3.36 7.5,7.5c0,2.97 -2.04,5.47 -5,6.88v1.12c0,0.59 0.25,1.12 0.66,1.5 3.97,-1.33 6.84,-5.08 6.84,-9.5 0,-5.52 -4.48,-10 -10,-10zm-1,5v4.27l3.32,1.92 0.75,-1.23 -2.57,-1.49V7H11z" />
</vector>`,
  },

  // 32. ic_brackets.xml (Red Bracket Category Icon)
  {
    path: 'app/src/main/res/drawable/ic_brackets.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector square bracket icon for red bracket game',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M4,4h6v2H6v12h4v2H4V4zm16,0h-6v2h4v12h-4v2h6V4z" />
</vector>`,
  },

  // 33. ic_users.xml (Group Jodi Category Icon)
  {
    path: 'app/src/main/res/drawable/ic_users.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector multiple users icon for group jodi',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M16,11c1.66,0 2.99,-1.34 2.99,-3S17.66,5 16,5c-1.66,0 -3,1.34 -3,3s1.34,3 3,3zm-8,0c1.66,0 2.99,-1.34 2.99,-3S9.66,5 8,5C6.34,5 5,6.34 5,8s1.34,3 3,3zm0,2c-2.33,0 -7,1.17 -7,3.5V19h14v-2.5c0,-2.33 -4.67,-3.5 -7,-3.5zm8,0c-0.29,0 -0.62,0.02 -0.97,0.05 1.16,0.84 1.97,1.97 1.97,3.45V19h6v-2.5c0,-2.33 -4.67,-3.5 -7,-3.5z" />
</vector>`,
  },

  // 34. ic_layout_grid.xml (Half Sangam Category Icon)
  {
    path: 'app/src/main/res/drawable/ic_layout_grid.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector layout grid icon for Sangam game',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M3,3h8v8H3V3zm10,0h8v8h-8V3zM3,13h8v8H3v-8zm10,0h8v8h-8v-8z" />
</vector>`,
  },

  // 35. ic_boxes.xml (Full Sangam Category Icon)
  {
    path: 'app/src/main/res/drawable/ic_boxes.xml',
    category: 'drawable',
    language: 'xml',
    description: 'Vector 3D boxes icon for Full Sangam game',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,3H5C3.9,3 3,3.9 3,5v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2V5C21,3.9 20.1,3 19,3zm-7,3l4,4 -4,4 -4,-4 4,-4zm-6,9.5V17h12v-1.5L12,12l-6,3.5z" />
</vector>`,
  },
];
