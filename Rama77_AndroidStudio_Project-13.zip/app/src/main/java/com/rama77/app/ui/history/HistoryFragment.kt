package com.rama77.app.ui.history

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.rama77.app.databinding.FragmentHistoryBinding

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return try {
            _binding = FragmentHistoryBinding.inflate(inflater, container, false)
            binding?.root
        } catch (e: Throwable) {
            inflater.inflate(com.rama77.app.R.layout.fragment_history, container, false)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            // 1. Game Bid History
            binding?.cardGameBidHistory?.setOnClickListener {
                openHistoryDetail("Game Bid History")
            }

            // 2. Starline Bid History
            binding?.cardStarlineBidHistory?.setOnClickListener {
                openHistoryDetail("Starline Bid History")
            }

            // 3. Jackpot Bid History
            binding?.cardJackpotBidHistory?.setOnClickListener {
                openHistoryDetail("Jackpot Bid History")
            }

            // 4. Game Result History
            binding?.cardGameResultHistory?.setOnClickListener {
                openHistoryDetail("Game Result History")
            }

            // 5. Starline Result History
            binding?.cardStarlineResultHistory?.setOnClickListener {
                openHistoryDetail("Starline Result History")
            }

            // 6. Jackpot Result History
            binding?.cardJackpotResultHistory?.setOnClickListener {
                openHistoryDetail("Jackpot Result History")
            }

        } catch (e: Throwable) {
            android.util.Log.e("HistoryFragment", "onViewCreated error: ${e.message}")
        }
    }

    private fun openHistoryDetail(title: String) {
        context?.let { ctx ->
            val intent = Intent(ctx, HistoryDetailActivity::class.java).apply {
                putExtra("HISTORY_TYPE", title)
            }
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
