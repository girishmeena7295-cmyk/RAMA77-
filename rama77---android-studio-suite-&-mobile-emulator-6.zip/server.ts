import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';
import { populateProjectZip } from './src/utils/projectZipGenerator';

// Initialize environment variables
dotenv.config();

const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Live Markets data synced with mobile app
const LIVE_MARKETS = [
  {
    id: '1',
    name: 'DEVI MORNING',
    openPana: '268',
    jodi: '60',
    closePana: '145',
    openTime: '08:55 AM',
    closeTime: '09:55 AM',
    status: 'Closed for Today',
    isOpen: false,
  },
  {
    id: '2',
    name: 'SURYA MORNING',
    openPana: '490',
    jodi: '38',
    closePana: '468',
    openTime: '10:05 AM',
    closeTime: '11:05 AM',
    status: 'Closed for Today',
    isOpen: false,
  },
  {
    id: '3',
    name: 'SRIDEVI',
    openPana: '147',
    jodi: '22',
    closePana: '589',
    openTime: '11:40 AM',
    closeTime: '12:42 PM',
    status: 'Closed for Today',
    isOpen: false,
  },
  {
    id: '4',
    name: 'TIME BAZAR',
    openPana: '670',
    jodi: '33',
    closePana: '580',
    openTime: '01:05 PM',
    closeTime: '02:05 PM',
    status: 'Closed for Today',
    isOpen: false,
  },
  {
    id: '5',
    name: 'MADHUR DAY',
    openPana: '369',
    jodi: '8*',
    closePana: '***',
    openTime: '01:35 PM',
    closeTime: '02:35 PM',
    status: 'Running for Close',
    isOpen: true,
  },
  {
    id: '6',
    name: 'SRIDEVI NIGHT',
    openPana: '290',
    jodi: '17',
    closePana: '188',
    openTime: '07:20 PM',
    closeTime: '08:20 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: '7',
    name: 'MADHUR NIGHT',
    openPana: '567',
    jodi: '81',
    closePana: '146',
    openTime: '08:30 PM',
    closeTime: '10:32 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: '8',
    name: 'MILAN NIGHT',
    openPana: '490',
    jodi: '37',
    closePana: '340',
    openTime: '09:05 PM',
    closeTime: '11:05 PM',
    status: 'Running for Open',
    isOpen: true,
  },
  {
    id: '9',
    name: 'KALYAN NIGHT',
    openPana: '166',
    jodi: '3*',
    closePana: '***',
    openTime: '09:25 PM',
    closeTime: '11:30 PM',
    status: 'Running for Close',
    isOpen: true,
  },
];

const GAME_RATES = [
  { gameType: 'Single Digit', winRatio: '1 ka 10' },
  { gameType: 'Single Pana', winRatio: '1 ka 160' },
  { gameType: 'Jodi Digit', winRatio: '1 ka 100' },
  { gameType: 'Double Pana', winRatio: '1 ka 320' },
  { gameType: 'Red Brackets', winRatio: '1 ka 100' },
  { gameType: 'Triple Pana', winRatio: '1 ka 900' },
  { gameType: 'Half Sangam A', winRatio: '1 ka 1000' },
  { gameType: 'Half Sangam B', winRatio: '1 ka 1000' },
  { gameType: 'Full Sangam Digits', winRatio: '1 ka 10000' },
];

async function createServer() {
  const app = express();

  app.use(cors());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // ------------------ PURE NATIVE ANDROID REST API (https://api.rama77.com/v1) ------------------

  // 1. Markets list (Both /api/v1/matka/markets and /api/v1/markets supported)
  const handleMarkets = (req: express.Request, res: express.Response) => {
    res.json({
      success: true,
      statusCode: 200,
      data: LIVE_MARKETS,
      markets: LIVE_MARKETS,
      count: LIVE_MARKETS.length,
      timestamp: new Date().toISOString(),
    });
  };

  app.get('/api/v1/matka/markets', handleMarkets);
  app.get('/api/v1/markets', handleMarkets);

  // 2. Single market detail
  app.get(['/api/v1/matka/markets/:id', '/api/v1/markets/:id'], (req, res) => {
    const market = LIVE_MARKETS.find((m) => m.id === req.params.id);
    if (!market) {
      return res.status(404).json({ success: false, message: 'Market not found' });
    }
    res.json({ success: true, data: market });
  });

  // 3. 4-Digit MPIN User Login
  app.post('/api/v1/auth/login', (req, res) => {
    const { phone, mpin } = req.body || {};
    res.json({
      success: true,
      statusCode: 200,
      message: 'Authentication successful',
      data: {
        phone: phone || '9876543210',
        userName: 'Girish Meena',
        walletBalance: 753,
        token: 'jwt_live_token_rama77_mobile',
      },
    });
  });

  // 4. Wallet Balance & Profile
  app.get(['/api/v1/user/wallet', '/api/v1/wallet'], (req, res) => {
    res.json({
      success: true,
      data: {
        phone: '9876543210',
        userName: 'Girish Meena',
        walletBalance: 753,
        currency: 'INR',
      },
    });
  });

  // 5. Place Bets from Sub-game screen
  app.post(['/api/v1/matka/bids/place', '/api/v1/bids/place'], (req, res) => {
    const { marketName, gameTitle, bets } = req.body || {};
    const totalPoints = Array.isArray(bets)
      ? bets.reduce((sum, b) => sum + (Number(b.points) || 0), 0)
      : 100;

    res.json({
      success: true,
      statusCode: 200,
      message: `Bid Placed Successfully! Total: ₹${totalPoints}`,
      data: {
        bidId: `BID-${Date.now()}`,
        marketName: marketName || 'KALYAN',
        gameTitle: gameTitle || 'Single Digit',
        totalPoints,
        remainingBalance: 753 - totalPoints,
      },
    });
  });

  // 6. Game Rates
  app.get(['/api/v1/matka/rates', '/api/v1/rates'], (req, res) => {
    res.json({
      success: true,
      data: GAME_RATES,
      rates: GAME_RATES,
    });
  });

  // 7. App Remote Config (Support contacts, deposit limits)
  app.get('/api/v1/admin/config', (req, res) => {
    res.json({
      success: true,
      data: {
        supportPhone: '6377972674',
        whatsappPhone: '916377972674',
        minDeposit: 300,
        maxDeposit: 500000,
        minWithdraw: 500,
        appVersion: '2.5',
        announcement: 'Welcome to RAMA77! Minimum deposit limit Rs. 300. Withdrawals processed 24/7.',
      },
    });
  });

  // ------------------ DIRECT DOWNLOAD ENDPOINTS ------------------

  // 1-Click Pure Android Studio Project ZIP Download
  app.get('/api/v1/download-project-zip', async (req, res, next) => {
    try {
      const zip = new JSZip();
      populateProjectZip(zip);
      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="Rama77_AndroidStudio_Project.zip"');
      res.setHeader('Content-Length', zipBuffer.length);
      res.send(zipBuffer);
    } catch (err) {
      next(err);
    }
  });

  // Direct Android APK Download endpoint
  app.get('/api/v1/download-apk', (req, res, next) => {
    try {
      const candidates = [
        path.resolve('public/RAMA77.apk'),
        '/tmp/Rama77_Build/app/build/outputs/apk/debug/app-debug.apk',
        '/tmp/Rama77_Build/app/build/outputs/apk/release/app-release-unsigned.apk',
      ];

      let foundPath: string | null = null;
      for (const candidate of candidates) {
        if (fs.existsSync(candidate)) {
          foundPath = candidate;
          break;
        }
      }

      if (!foundPath) {
        return res.status(202).json({
          status: 'ready_via_zip',
          message: 'Please download the Pure Android Studio Project ZIP to build in Android Studio or GitHub Actions.',
          downloadZipUrl: '/api/v1/download-project-zip',
        });
      }

      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', 'attachment; filename="RAMA77-v2.5.apk"');
      const fileStream = fs.createReadStream(foundPath);
      fileStream.pipe(res);
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/v1/apk-status', (req, res) => {
    const candidates = [
      path.resolve('public/RAMA77.apk'),
      '/tmp/Rama77_Build/app/build/outputs/apk/debug/app-debug.apk',
    ];
    const ready = candidates.some((p) => fs.existsSync(p));
    res.json({
      ready,
      downloadUrl: ready ? '/api/v1/download-apk' : '/api/v1/download-project-zip',
      zipDownloadUrl: '/api/v1/download-project-zip',
    });
  });

  // ------------------ VITE / STATIC SERVING ------------------
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve('dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Error handling
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('[API_ERROR]', err?.message || err);
    res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: 'An unexpected internal error occurred.',
    });
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[RAMA77 NATIVE USER APP SERVER] Running on port ${PORT}`);
    console.log(`[RAMA77 NATIVE USER APP SERVER] Pure Native Android REST API: Active`);
    console.log(`[RAMA77 NATIVE USER APP SERVER] Live Endpoint: https://api.rama77.com/v1`);
  });
}

createServer().catch((err) => {
  console.error('[FATAL_STARTUP_ERROR]', err);
  process.exit(1);
});
