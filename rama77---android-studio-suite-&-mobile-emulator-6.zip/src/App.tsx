import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  CheckCircle2,
  Globe2,
  ShieldCheck,
  Cpu,
  FolderArchive,
  Terminal,
} from 'lucide-react';
import { PhoneFrame } from './components/AndroidEmulator/PhoneFrame';
import { downloadAndroidStudioZip } from './utils/projectZipGenerator';

export default function App() {
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      await downloadAndroidStudioZip();
    } catch (e) {
      console.error('Failed to generate ZIP archive:', e);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadApk = () => {
    setIsDownloadingApk(true);
    window.location.href = '/api/v1/download-apk';
    setTimeout(() => setIsDownloadingApk(false), 3000);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-orange-500 selection:text-white">
      {/* Top Bar Header */}
      <header className="sticky top-0 z-40 bg-zinc-900/95 backdrop-blur-md border-b border-zinc-800 px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand Zone */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#F16521] to-[#E05410] flex items-center justify-center text-white font-black text-xl shadow-md">
            R
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base sm:text-lg text-white tracking-tight">
                RAMA77
              </h1>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                Pure Native Android User App
              </span>
            </div>
            <p className="text-xs text-zinc-400 hidden sm:flex items-center gap-1.5 mt-0.5">
              <span>Pure Kotlin + XML Android Studio Project</span>
              <span className="text-zinc-600">·</span>
              <span className="text-emerald-400 font-medium flex items-center gap-1">
                <Globe2 className="w-3 h-3" />
                Live API: https://api.rama77.com/v1
              </span>
            </p>
          </div>
        </div>

        {/* Live API & Action Buttons */}
        <div className="flex items-center gap-2.5">
          {/* Live API Endpoint Status Pill */}
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-mono text-zinc-400">Endpoint:</span>
            <span className="text-emerald-400 font-semibold font-mono">api.rama77.com/v1</span>
          </div>

          {/* Direct 1-Click APK Download */}
          <button
            onClick={handleDownloadApk}
            disabled={isDownloadingApk}
            className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
            title="Download executable APK (.apk) for instant mobile installation"
          >
            <Smartphone className="w-4 h-4 text-emerald-200" />
            <span>{isDownloadingApk ? 'Downloading APK...' : 'Download APK (.apk)'}</span>
          </button>

          {/* 1-Click Pure Android Studio ZIP Download */}
          <button
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#F16521] to-[#D84B06] hover:from-[#e05410] hover:to-[#c44307] text-white font-bold text-xs rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
            title="Download pure Kotlin + XML Android Studio Project ZIP"
          >
            <Download className="w-4 h-4" />
            <span>{isDownloading ? 'Generating ZIP...' : 'Download Project ZIP'}</span>
          </button>
        </div>
      </header>

      {/* Main Container: Focused on Live Android Mobile Emulator & Native Specs */}
      <main className="flex-1 p-3 sm:p-6 max-w-[1400px] w-full mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start justify-center">
          
          {/* Left/Center: Pure Native Android User App Mobile Phone Mockup */}
          <div className="lg:col-span-6 xl:col-span-5 flex flex-col items-center">
            <div className="w-full max-w-[390px] mb-3 flex items-center justify-between px-2 text-xs">
              <span className="font-bold flex items-center gap-1.5 text-orange-400">
                <Smartphone className="w-4 h-4" />
                RAMA77 Mobile App (Pure Native)
              </span>
              <span className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Live API Synced
              </span>
            </div>
            <PhoneFrame />
          </div>

          {/* Right: Pure Native Android Architecture & API Integration Details */}
          <div className="lg:col-span-6 xl:col-span-7 space-y-4">
            
            {/* Project Overview Card */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <FolderArchive className="w-5 h-5 text-orange-500" />
                    Pure Native Android Studio Package
                  </h2>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    100% Native Kotlin &amp; Material Design 3 architecture — zero web/admin bloat
                  </p>
                </div>
                <button
                  onClick={handleDownloadZip}
                  disabled={isDownloading}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download ZIP</span>
                </button>
              </div>

              {/* Native Architecture Highlights Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-zinc-950/70 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center gap-2 text-orange-400 font-bold">
                    <Cpu className="w-4 h-4" />
                    <span>Pure Kotlin 1.9+ &amp; Android 14</span>
                  </div>
                  <p className="text-zinc-400 text-[11px] leading-relaxed">
                    Min SDK 24 (Android 7.0) to Target SDK 34 (Android 14). Fully compiled with Gradle 8.7 &amp; AGP 8.4.1.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-zinc-950/70 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <Globe2 className="w-4 h-4" />
                    <span>Live Production API Integration</span>
                  </div>
                  <p className="text-zinc-400 text-[11px] leading-relaxed">
                    Configured for <code className="text-emerald-300 font-mono">https://api.rama77.com/v1</code> with Retrofit 2, OkHttp 4, and GSON converter.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-zinc-950/70 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center gap-2 text-blue-400 font-bold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Hardened Hardware Security</span>
                  </div>
                  <p className="text-zinc-400 text-[11px] leading-relaxed">
                    BiometricPrompt fingerprint authentication, EncryptedSharedPreferences, safe context handling, and root detection.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-zinc-950/70 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center gap-2 text-purple-400 font-bold">
                    <Terminal className="w-4 h-4" />
                    <span>GitHub Actions Automated CI</span>
                  </div>
                  <p className="text-zinc-400 text-[11px] leading-relaxed">
                    Pre-configured <code className="text-purple-300 font-mono">.github/workflows/build-apk.yml</code> workflow for 1-click APK exports.
                  </p>
                </div>
              </div>

              {/* Live API Endpoints Box */}
              <div className="p-4 rounded-2xl bg-zinc-950/90 border border-zinc-800 font-mono text-[11px] space-y-2">
                <div className="text-zinc-400 font-semibold text-xs flex items-center justify-between pb-1 border-b border-zinc-800">
                  <span className="text-zinc-300 font-sans">Active Live API Endpoints (https://api.rama77.com/v1)</span>
                  <span className="text-emerald-400 flex items-center gap-1 font-sans text-[10px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    SYNCING
                  </span>
                </div>
                <div className="space-y-1.5 text-zinc-300 pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400 font-bold w-12">GET</span>
                    <span className="text-zinc-400">/api/v1/matka/markets</span>
                    <span className="text-zinc-500 text-[10px] ml-auto font-sans">Live market lists &amp; pana numbers</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-blue-400 font-bold w-12">POST</span>
                    <span className="text-zinc-400">/api/v1/auth/login</span>
                    <span className="text-zinc-500 text-[10px] ml-auto font-sans">4-Digit MPIN authentication</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400 font-bold w-12">GET</span>
                    <span className="text-zinc-400">/api/v1/user/wallet</span>
                    <span className="text-zinc-500 text-[10px] ml-auto font-sans">Real-time wallet balance</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-blue-400 font-bold w-12">POST</span>
                    <span className="text-zinc-400">/api/v1/matka/bids/place</span>
                    <span className="text-zinc-500 text-[10px] ml-auto font-sans">Sub-game bet submissions</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400 font-bold w-12">GET</span>
                    <span className="text-zinc-400">/api/v1/matka/rates</span>
                    <span className="text-zinc-500 text-[10px] ml-auto font-sans">Live win payout ratios</span>
                  </div>
                </div>
              </div>

              {/* Android Studio Folder Structure Tree */}
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-[11px] font-mono text-zinc-400 space-y-1">
                <div className="text-zinc-300 font-semibold mb-2 font-sans flex items-center justify-between">
                  <span>Pure Android Project Structure in ZIP:</span>
                  <span className="text-xs text-orange-400 font-bold">226 Clean Files</span>
                </div>
                <div className="text-zinc-300">Rama77/</div>
                <div className="pl-3 text-zinc-400">├── app/</div>
                <div className="pl-6 text-zinc-400">├── src/main/java/com/rama77/app/</div>
                <div className="pl-9 text-emerald-400">├── MainActivity.kt, DashboardActivity.kt</div>
                <div className="pl-9 text-emerald-400">├── ui/ (login, register, home, funds, passbook, support, charts...)</div>
                <div className="pl-9 text-emerald-400">├── network/ (RetrofitClient.kt, ApiService.kt, ApiModels.kt)</div>
                <div className="pl-9 text-emerald-400">├── adapter/ &amp; model/ (MarketAdapter, GameOption, BetItem...)</div>
                <div className="pl-6 text-zinc-400">├── src/main/res/</div>
                <div className="pl-9 text-orange-400">├── layout/ (activity_main.xml, fragment_home.xml, item_market_card.xml...)</div>
                <div className="pl-9 text-orange-400">├── drawable/ (vector drawables, shape badges, buttons)</div>
                <div className="pl-9 text-orange-400">├── values/ (colors.xml, strings.xml, themes.xml)</div>
                <div className="pl-6 text-zinc-300">├── AndroidManifest.xml</div>
                <div className="pl-6 text-zinc-300">└── build.gradle</div>
                <div className="pl-3 text-zinc-400">├── gradle/ (wrapper &amp; libs.versions.toml)</div>
                <div className="pl-3 text-zinc-400">├── .github/workflows/build-apk.yml</div>
                <div className="pl-3 text-zinc-300">├── build.gradle &amp; settings.gradle</div>
                <div className="pl-3 text-zinc-300">└── gradlew &amp; gradlew.bat</div>
              </div>

              {/* Fast 1-Click Action */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  onClick={handleDownloadZip}
                  disabled={isDownloading}
                  className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-5 py-3 bg-gradient-to-r from-[#F16521] to-[#D84B06] hover:from-[#e05410] hover:to-[#c44307] text-white font-extrabold text-sm rounded-2xl shadow-xl transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  <Download className="w-5 h-5" />
                  <span>{isDownloading ? 'Generating ZIP...' : 'Download Pure Android Studio Project (.ZIP)'}</span>
                </button>
                <button
                  onClick={handleDownloadApk}
                  disabled={isDownloadingApk}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-2xl shadow-md transition-all cursor-pointer active:scale-98"
                >
                  <Smartphone className="w-4 h-4 text-emerald-200" />
                  <span>Download APK (.apk)</span>
                </button>
              </div>

            </div>
          </div>
        </div>
      </main>

      {/* Bottom Sticky Helper Banner */}
      <footer className="bg-zinc-900 border-t border-zinc-800 py-3 px-6 text-center text-xs text-zinc-500 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Pure Native Android Studio Project</span>
          <span className="mx-1">·</span>
          <span>Kotlin 1.9+</span>
          <span className="mx-1">·</span>
          <span>Material Design 3</span>
          <span className="mx-1">·</span>
          <span className="text-emerald-400">API: https://api.rama77.com/v1</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={handleDownloadApk}
            className="text-emerald-400 font-semibold hover:underline cursor-pointer flex items-center gap-1.5"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Download Direct APK (.apk)</span>
          </button>
          <span className="text-zinc-600">|</span>
          <button
            onClick={handleDownloadZip}
            className="text-orange-400 font-semibold hover:underline cursor-pointer"
          >
            Download Android Studio Project (.ZIP) ➔
          </button>
        </div>
      </footer>
    </div>
  );
}
